import { RouterModule , Routes } from "@angular/router";
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './form/register/register.component';
import { LoginComponent } from './form/login/login.component';
import { AdminComponent } from './form/admin/admin.component';
import { UnauthorizedComponent } from './form/unauthorized/unauthorized.component';
import { AuthGuard } from './auth-guard.service';
import { AuthService } from './auth.service';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FaqComponent } from './faq/faq.component';

const APP_ROUTES:Routes=[

{ path:'' , component: HomeComponent } ,
{ path:'contact-us' , component: ContactUsComponent } ,
{ path:'faq' , component: FaqComponent } ,
{ path:'register' , component: RegisterComponent } ,
{ path:'login' , component: LoginComponent } ,
{ path: 'admin', component: AdminComponent, canActivate: [AuthGuard] } ,
{ path: 'unauthorized', component: UnauthorizedComponent } ,
{ path:'**' , redirectTo:'' , pathMatch:'full' }

]

export const routing = RouterModule.forRoot(APP_ROUTES);