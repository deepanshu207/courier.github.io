import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MenubarComponent } from './menubar/menubar.component';
import { HomeComponent } from './home/home.component';
import { routing } from './app.routing';
import { RouterModule } from '@angular/router';
import { RegisterComponent } from './form/register/register.component';
import { LoginComponent } from './form/login/login.component';

import { FormsModule } from '@angular/forms';

import { AuthService } from './auth.service';

import { HttpModule } from '@angular/http';
import { AdminComponent } from './form/admin/admin.component';
import { UnauthorizedComponent } from './form/unauthorized/unauthorized.component';
import { AuthGuard } from './auth-guard.service';
import { SecureStuffComponent } from './form/secure-stuff/secure-stuff.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FaqComponent } from './faq/faq.component';

@NgModule({
  declarations: [
    AppComponent,
    MenubarComponent,
    HomeComponent,
    RegisterComponent,
    LoginComponent,
    AdminComponent,
    UnauthorizedComponent,
    SecureStuffComponent,
    ContactUsComponent,
    FaqComponent
  ],
  imports: [
    BrowserModule,routing,RouterModule,FormsModule,HttpModule
  ],
  providers: [AuthService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
